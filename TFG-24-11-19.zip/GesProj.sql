-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 24-11-2019 a las 16:35:10
-- Versión del servidor: 10.4.8-MariaDB
-- Versión de PHP: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `GesProj`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Anotaciones`
--

CREATE TABLE `Anotaciones` (
  `pk_idAnotacion` int(6) NOT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` mediumtext COLLATE utf8_spanish_ci NOT NULL,
  `tipo` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `fk_idTarea` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Proyectos`
--

CREATE TABLE `Proyectos` (
  `pk_idProyecto` int(6) NOT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` mediumtext COLLATE utf8_spanish_ci NOT NULL,
  `fechaInicio` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fechaFinalizacion` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `estado` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `estimacion` varchar(10) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `Proyectos`
--

INSERT INTO `Proyectos` (`pk_idProyecto`, `nombre`, `descripcion`, `fechaInicio`, `fechaFinalizacion`, `estado`, `estimacion`) VALUES
(999, 'pruebas', 'proyecto de pruebas', '2019-10-30 20:51:02', '0000-00-00 00:00:00', 'en proceso', '5h');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Tareas`
--

CREATE TABLE `Tareas` (
  `pk_idTarea` int(6) NOT NULL,
  `fk_idProyecto` int(6) NOT NULL,
  `nombreTarea` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` mediumtext COLLATE utf8_spanish_ci NOT NULL,
  `fechaInicio` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fechaFinalizacion` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `estado` varchar(60) COLLATE utf8_spanish_ci NOT NULL,
  `estimacion` varchar(10) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `Tareas`
--

INSERT INTO `Tareas` (`pk_idTarea`, `fk_idProyecto`, `nombreTarea`, `descripcion`, `fechaInicio`, `fechaFinalizacion`, `estado`, `estimacion`) VALUES
(3, 999, 'TareaPrueba', 'TareaPruebas', '2019-10-30 20:55:53', '0000-00-00 00:00:00', 'en proceso', '1h');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Usuarios`
--

CREATE TABLE `Usuarios` (
  `pk_correo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `imagen` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `contrasenia` varchar(1000) COLLATE utf8_spanish_ci NOT NULL,
  `rol` int(3) NOT NULL,
  `fCreacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` varchar(10) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `Usuarios`
--

INSERT INTO `Usuarios` (`pk_correo`, `nombre`, `apellidos`, `imagen`, `contrasenia`, `rol`, `fCreacion`, `estado`) VALUES
('platano@rojastorres.es', 'platano', 'platano', 'default.png', '$2y$10$TmM./o5u1BtVgMN/h32AhO/OQHDdTm8Rrh4dq1WcWyzozBlK.h.UK', 0, '2019-11-17 11:33:53', ''),
('pruebas@rojastorres.esplatano', 'pruebas', 'pruebas', 'default.png', '$2y$10$0WaTWd8Cz9XRw.lRYEtQhOWnfQwwm/3nCSbi4pa131ObOHd26flsy', 0, '2019-11-22 17:25:21', 'NoActivo'),
('pruebas123123@movatec.es', 'pruebas', 'pruebas', 'default.png', '$2y$10$2ciymK7krqH.w2MhGbn6ROS0lrJFS/dylbJXOkvxrCVRp09xR5GZO', 0, '2019-11-22 17:27:15', 'NoActivo'),
('pruebas312@rojastorres.es', 'platano', 'pruebas', 'default.png', '$2y$10$Ns1jTLLTLDbSDCxNmrvT2ueNQoiN/LKwu.CGlsrYYLg0TGD.HzwdG', 0, '2019-11-22 17:26:34', 'NoActivo'),
('pruebas31223@rojastorres.es', 'platano', 'pruebas', 'default.png', '$2y$10$RV85N39JUt8u5hPAEckgu.m9s.OaqZ4sDuEF7JaGAqvzjuk.5E16C', 0, '2019-11-22 17:26:47', 'NoActivo'),
('sergio@rojastorres.es', 'Sergi', 'Rojas Torres', '670bfd5ac31e038780898469c836102d5712.jpeg', '$2y$10$uGPDF3V6GJh83ObHDT7asOLxVKUNSN8akuZ2NSs9fGMJBlmbxF/CS', 100, '2019-11-17 11:33:53', ''),
('sergiorojastorres2@gmail.com', 'platano', 'rojas torres', 'default.png', '$2y$10$AH94zy8HxRyForoo3VZ66u1ozkhoCAm4k2x4qfYjD7YiMenjJCNBS', 0, '2019-11-17 11:33:53', ''),
('usuarioPrueba@rojastorres.es', 'Usuario1', 'usuario1', '74e27da0bd41a1a006958d2075c45e055410.png', '$2y$10$M3AiFItZWosR7LfDj6ehNer5HPz58bUgL8gx9.bs7Rm9n9mg14k8C', 1, '2019-11-17 11:33:53', ''),
('usuarioPrueba2@rojastorres.es', 'Usuario2', 'prueba', '89d442b17d69eb9ec0897313d6f1af986622.png', '$2y$10$5hnzyI9OVB1fh3UU/Mut4OlJLxU3hi7wpW.dHxhvQ/AOX96MLul3e', 0, '2019-11-17 11:33:53', ''),
('usuarioPrueba3@rojastorres.es', 'Usuario3', 'prueba', '19f933c19e57eabad242e92634ebb5f03914.png', '$2y$10$l1W9MvTSobOLYaJC9.956OqFa9AOUvXmZ9ilQZ2H6VuZW3FREokx2', 100, '2019-11-17 11:33:53', ''),
('usuarioPrueba4@rojastorres.es', 'Usuario3', 'prueba', '19f933c19e57eabad242e92634ebb5f03914.png', '$2y$10$l1W9MvTSobOLYaJC9.956OqFa9AOUvXmZ9ilQZ2H6VuZW3FREokx2', 0, '2019-11-21 12:35:22', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Usuarios:Anotaciones`
--

CREATE TABLE `Usuarios:Anotaciones` (
  `fk_correo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `fk_idAnotacion` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Usuarios:Proyectos`
--

CREATE TABLE `Usuarios:Proyectos` (
  `fk_correo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `fk_idProyecto` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Usuarios:Tareas`
--

CREATE TABLE `Usuarios:Tareas` (
  `fk_correo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `fk_idTarea` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `Anotaciones`
--
ALTER TABLE `Anotaciones`
  ADD PRIMARY KEY (`pk_idAnotacion`),
  ADD KEY `fk_Anotaciones_Tareas` (`fk_idTarea`);

--
-- Indices de la tabla `Proyectos`
--
ALTER TABLE `Proyectos`
  ADD PRIMARY KEY (`pk_idProyecto`),
  ADD KEY `pk_idProyecto` (`pk_idProyecto`);

--
-- Indices de la tabla `Tareas`
--
ALTER TABLE `Tareas`
  ADD PRIMARY KEY (`pk_idTarea`),
  ADD KEY `fk_Tareas_Proyectos` (`fk_idProyecto`);

--
-- Indices de la tabla `Usuarios`
--
ALTER TABLE `Usuarios`
  ADD PRIMARY KEY (`pk_correo`),
  ADD KEY `pk_correo` (`pk_correo`);

--
-- Indices de la tabla `Usuarios:Anotaciones`
--
ALTER TABLE `Usuarios:Anotaciones`
  ADD KEY `fk_Usuarios:Anotaciones_Usuarios` (`fk_correo`),
  ADD KEY `fk_Usuarios:Anotaciones_Anotacion` (`fk_idAnotacion`);

--
-- Indices de la tabla `Usuarios:Proyectos`
--
ALTER TABLE `Usuarios:Proyectos`
  ADD KEY `fk_Usuarios:Proyecto_Proyectos` (`fk_idProyecto`),
  ADD KEY `fk_Usuarios:Proyecto_Usuarios` (`fk_correo`);

--
-- Indices de la tabla `Usuarios:Tareas`
--
ALTER TABLE `Usuarios:Tareas`
  ADD KEY `fk_Usuarios:Tareas_Usuarios` (`fk_correo`),
  ADD KEY `fk_Usuarios:Tareas_Tarea` (`fk_idTarea`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `Anotaciones`
--
ALTER TABLE `Anotaciones`
  MODIFY `pk_idAnotacion` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `Proyectos`
--
ALTER TABLE `Proyectos`
  MODIFY `pk_idProyecto` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1000;

--
-- AUTO_INCREMENT de la tabla `Tareas`
--
ALTER TABLE `Tareas`
  MODIFY `pk_idTarea` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `Anotaciones`
--
ALTER TABLE `Anotaciones`
  ADD CONSTRAINT `fk_Anotaciones_Tareas` FOREIGN KEY (`fk_idTarea`) REFERENCES `Tareas` (`pk_idTarea`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `Tareas`
--
ALTER TABLE `Tareas`
  ADD CONSTRAINT `fk_Tareas_Proyectos` FOREIGN KEY (`fk_idProyecto`) REFERENCES `Proyectos` (`pk_idProyecto`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `Usuarios:Anotaciones`
--
ALTER TABLE `Usuarios:Anotaciones`
  ADD CONSTRAINT `fk_Usuarios:Anotaciones_Anotacion` FOREIGN KEY (`fk_idAnotacion`) REFERENCES `Anotaciones` (`pk_idAnotacion`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Usuarios:Anotaciones_Usuarios` FOREIGN KEY (`fk_correo`) REFERENCES `Usuarios` (`pk_correo`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `Usuarios:Proyectos`
--
ALTER TABLE `Usuarios:Proyectos`
  ADD CONSTRAINT `fk_Usuarios:Proyecto_Proyectos` FOREIGN KEY (`fk_idProyecto`) REFERENCES `Proyectos` (`pk_idProyecto`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Usuarios:Proyecto_Usuarios` FOREIGN KEY (`fk_correo`) REFERENCES `Usuarios` (`pk_correo`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `Usuarios:Tareas`
--
ALTER TABLE `Usuarios:Tareas`
  ADD CONSTRAINT `fk_Usuarios:Tareas_Tarea` FOREIGN KEY (`fk_idTarea`) REFERENCES `Tareas` (`pk_idTarea`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Usuarios:Tareas_Usuarios` FOREIGN KEY (`fk_correo`) REFERENCES `Usuarios` (`pk_correo`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
