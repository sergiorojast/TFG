## TFG -> GesProj
### Trabajo de fin de grado (Grado superior Desarrollo de aplicaciones web)

Este proyecto trata sobre un "Gestor de proyectos", el cual nos permitira gestionar diferentes tipos de actividades, a las cuales se les podra añadir tareas.

Para el acceso a los datos de la BD, se hara por medio de un servicio web.

 La aplicación tendra varios roles

#### Roles
 El apartado de permisos se gestionara por medio de un campo numerico.
 
    -Administrador
    -Avanzado
    -usuario
Para el hash de las contraseñas usamos PASSWORD_BCRYPT
